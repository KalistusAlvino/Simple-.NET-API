using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OrderServices.DAL.Interface;
using OrderServices.Models;

namespace OrderServices.DAL
{
    public class OrderDetailDAL : IOrderDetail
{
        public void Delete(OrderDetail obj)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<OrderDetail> GetAll()
        {
            throw new NotImplementedException();
        }

        public OrderDetail GetById(int id)
        {
            throw new NotImplementedException();
        }

        public void Insert(OrderDetail obj)
        {
            throw new NotImplementedException();
        }

        public void Update(OrderDetail obj)
        {
            throw new NotImplementedException();
        }
    }
}