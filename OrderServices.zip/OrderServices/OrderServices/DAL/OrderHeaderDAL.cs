using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using OrderServices.DAL.Interface;
using OrderServices.Models;
using System.Data.SqlClient;
using Dapper;

namespace OrderServices.DAL
{
    public class OrderHeaderDAL : IOrderHeader
    {
        private readonly IConfiguration _config;
        public OrderHeaderDAL(IConfiguration config)
        {
            _config = config;
        }
        private string GetConnectionString()
        {
            return _config.GetConnectionString("DefaultConnection");
        }
        public void Delete(OrderHeader obj)
        {
            using (var connection = new SqlConnection(GetConnectionString()))
            {
                var strSql = @"DELETE FROM OrderHeaders WHERE OrderHeaderId = @OrderHeaderId";
                var param = new { OrderHeaderId = obj.OrderHeaderId };
                try
                {
                    connection.Execute(strSql, param);
                }
                catch (SqlException sqlEx)
                {
                    throw new ArgumentException(sqlEx.Message);
                }
            }
        }

        public IEnumerable<OrderHeader> GetAll()
        {
            using (var connection = new SqlConnection(GetConnectionString()))
            {
                var strSql = @"SELECT * FROM OrderHeaders";
                return connection.Query<OrderHeader>(strSql);
            }
        }

        public OrderHeader GetById(int id)
        {
            using (var connection = new SqlConnection(GetConnectionString()))
            {
                var strSql = @"SELECT * FROM OrderHeaders WHERE OrderHeaderId = @OrderHeaderId";
                return (OrderHeader)connection.Query<OrderHeader>(strSql);
            }
        }

        public void Insert(OrderHeader obj)
        {
            using (var connection = new SqlConnection(GetConnectionString()))
            {
                var strSql = @"INSERT INTO OrderHeaders (CustomerId, OrderDate) VALUES (@CustomerId, @OrderDate)";
                var param = new { CustomerId = obj.CustomerId, OrderDate = DateTime.Now };
                try
                {
                    connection.Execute(strSql, param);
                }
                catch (SqlException sqlEx)
                {
                    throw new ArgumentException($"Error: {sqlEx.Message} - {sqlEx.Number}");
                }
                catch (Exception ex)
                {
                    throw new ArgumentException($"Error: {ex.Message}");
                }
            }
        }

        public void Update(OrderHeader obj)
        {
            using (var connection = new SqlConnection(GetConnectionString()))
            {
                var strSql = @"UPDATE OrderHeaders SET CustomerId = @CustomerId, OrderDate = @OrderDate WHERE OrderHeaderId = @OrderHeaderId";
                var param = new { CustomerId = obj.CustomerId, OrderDate = obj.OrderDate, OrderHeaderId = obj.OrderHeaderId };
                try
                {
                    connection.Execute(strSql, param);
                }
                catch (SqlException sqlEx)
                {
                    throw new ArgumentException($"Error: {sqlEx.Message} - {sqlEx.Number}");
                }
                catch (Exception ex)
                {
                    throw new ArgumentException($"Error: {ex.Message}");
                }
            }

        }
    }
}