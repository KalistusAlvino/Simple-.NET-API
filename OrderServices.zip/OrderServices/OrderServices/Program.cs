
using OrderServices.DAL;
using OrderServices.DAL.Interface;
using OrderServices.Models;

var builder = WebApplication.CreateBuilder(args);


builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddScoped<ICustomer, CustomerDAL>();
builder.Services.AddScoped<IOrderHeader, OrderHeaderDAL>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();



app.MapGet("api/customers", (ICustomer CustomerDAL) =>
{
    var customer = CustomerDAL.GetAll();
    return Results.Ok(customer);
});

app.MapPost("api/customers", (ICustomer CustomerDAL, Customer customer) =>
{
    try{
        CustomerDAL.Insert(customer);
        return Results.Created($"/api/customers/{customer.CustomerId}", customer);
    }
    catch(Exception ex){
        return Results.BadRequest(ex.Message);
    }
});

app.MapGet("api/orderHeaders", (IOrderHeader OrderHeaderDAL) =>
{
    var orderHeader = OrderHeaderDAL.GetAll();
    return Results.Ok(orderHeader);
});

app.MapPost("api/orderHeaders", (IOrderHeader OrderHeaderDAL, OrderHeader orderHeader) =>
{
    try{
        OrderHeaderDAL.Insert(orderHeader);
        return Results.Created($"/api/orderHeaders/{orderHeader.OrderHeaderId}", orderHeader);
    }
    catch(Exception ex){
        return Results.BadRequest(ex.Message);
    }
});


app.Run();

record WeatherForecast(DateOnly Date, int TemperatureC, string? Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}
